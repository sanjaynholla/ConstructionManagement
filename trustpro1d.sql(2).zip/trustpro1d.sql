-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 01, 2016 at 04:32 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `trustpro1d`
--

-- --------------------------------------------------------

--
-- Table structure for table `remainings`
--

CREATE TABLE IF NOT EXISTS `remainings` (
  `wno` int(8) NOT NULL,
  `product1` varchar(20) NOT NULL,
  `unit1` varchar(20) NOT NULL,
  `price1` double NOT NULL,
  `product2` varchar(20) NOT NULL,
  `unit2` varchar(20) NOT NULL,
  `price2` double NOT NULL,
  `product3` varchar(20) NOT NULL,
  `unit3` varchar(20) NOT NULL,
  `price3` double NOT NULL,
  `quantity1` float NOT NULL,
  `quantity2` float NOT NULL,
  `quantity3` float NOT NULL,
  `total` float NOT NULL,
  `balance` float NOT NULL,
  PRIMARY KEY (`wno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remainings`
--

INSERT INTO `remainings` (`wno`, `product1`, `unit1`, `price1`, `product2`, `unit2`, `price2`, `product3`, `unit3`, `price3`, `quantity1`, `quantity2`, `quantity3`, `total`, `balance`) VALUES
(1, 'Cement Brick', 'piece', 20, 'Stones', 'pieces', 20, 'Cement', 'pieces', 200, 2, 2, 2, 480, 41920),
(3, 'Cement Bric', 'kg', 350, 'Cement', 'pieces', 200, 'Cement', 'pieces', 30, 25, 65, 38, 22890, 0);

-- --------------------------------------------------------

--
-- Table structure for table `trustpro1t`
--

CREATE TABLE IF NOT EXISTS `trustpro1t` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `trustpro1t`
--

INSERT INTO `trustpro1t` (`id`, `name`, `password`) VALUES
(1, 'trust', 'trust');

-- --------------------------------------------------------

--
-- Table structure for table `trustpro2t`
--

CREATE TABLE IF NOT EXISTS `trustpro2t` (
  `workno` int(8) NOT NULL,
  `type` char(25) NOT NULL,
  `cost` float NOT NULL,
  `emd` float NOT NULL,
  `securitydep` float NOT NULL,
  `itax` float NOT NULL,
  `royalty` float NOT NULL,
  `nsc` float NOT NULL,
  `cbs` char(20) NOT NULL,
  `salestax` float NOT NULL,
  `remark` varchar(22) NOT NULL,
  `producttype1` varchar(11) NOT NULL,
  `quantity1` float NOT NULL,
  `price1` float NOT NULL,
  `unit1` varchar(8) NOT NULL,
  `producttype2` varchar(11) NOT NULL,
  `quantity2` float NOT NULL,
  `unit2` varchar(11) NOT NULL,
  `price2` float NOT NULL,
  `producttype3` varchar(11) NOT NULL,
  `quantity3` float NOT NULL,
  `unit3` varchar(11) NOT NULL,
  `price3` float NOT NULL,
  `dat` date NOT NULL,
  `sitena` varchar(20) NOT NULL,
  `labour` varchar(10) NOT NULL,
  `labourco` float NOT NULL,
  `labourno` int(5) NOT NULL,
  `inventarycost` double NOT NULL,
  `totalexp` double NOT NULL,
  `balance` double NOT NULL,
  `totallabour` double NOT NULL,
  PRIMARY KEY (`workno`),
  UNIQUE KEY `workno` (`workno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trustpro2t`
--

INSERT INTO `trustpro2t` (`workno`, `type`, `cost`, `emd`, `securitydep`, `itax`, `royalty`, `nsc`, `cbs`, `salestax`, `remark`, `producttype1`, `quantity1`, `price1`, `unit1`, `producttype2`, `quantity2`, `unit2`, `price2`, `producttype3`, `quantity3`, `unit3`, `price3`, `dat`, `sitena`, `labour`, `labourco`, `labourno`, `inventarycost`, `totalexp`, `balance`, `totallabour`) VALUES
(1, 'Road', 50000, 5000, 2500, 1250, 1000, 1000, 'Sagar', 2000, 'Complete Within A Week', 'Cement', 25, 200, 'bag', 'Cem', 65, 'pieces', 200, 'Large Stone', 11, 'pieces', 30, '0000-00-00', 'surangadde', 'males', 500, 66, 18330, 32080, 17920, 0),
(2, 'Building', 200000, 20000, 10000, 5000, 4000, 4000, 'Surangadde', 8000, 'Complete within a Year', '', 0, 0, '', '', 0, '', 0, '', 0, '', 0, '2015-12-22', 'surangadde', 'males', 200, 3, 0, 51600, 148400, 600),
(3, 'Building', 500000, 50000, 25000, 12500, 10000, 10000, 'Surangadde', 20000, 'completed within 2 yea', 'Cement Bric', 25, 350, 'kg', 'Cement', 65, 'pieces', 200, 'Cement', 38, 'pieces', 30, '2015-12-22', 'surangadde', 'males', 200, 60, 22890, 164890, 335110, 12000),
(4, 'Drainages', 500090, 50009, 25004.5, 12502.2, 10001.8, 10001.8, 'Pragati', 20003.6, 'Complete within 15th O', '', 0, 0, '', '', 0, '', 0, '', 0, '', 0, '0000-00-00', '', '', 0, 0, 0, 127522.9, 372567.1, 0),
(5, 'Roads', 50000, 5000, 2500, 1250, 1000, 1000, 'Pragati', 2000, 'Complete within a week', 'Cement Bric', 45, 350, 'piece', 'Large Stone', 54, 'gm', 40, 'Cement', 100, 'pieces', 20, '2015-12-22', 'surangadde', 'males', 200, 3, 19910, 0, 0, 600),
(6, 'concrete road', 200000, 20000, 10000, 5000, 4000, 4000, 'talaguppa', 8000, 'complete within 1 week', 'Cement Bric', 45, 200, 'bag', 'Large Stone', 54, 'pieces', 200, 'Stones', 44, 'pieces', 200, '2015-12-22', 'talaguppa', 'males', 500, 60, 28600, 110600, 89400, 30000),
(90, 'Road', 50000, 5000, 2500, 1250, 1000, 1000, 'Surangadde', 2000, 'good', '', 0, 0, '', '', 0, '', 0, '', 0, '', 0, '0000-00-00', '', '', 0, 0, 0, 12750, 37250, 0);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE IF NOT EXISTS `vehicle` (
  `workno` int(10) NOT NULL,
  `date` date NOT NULL,
  `vehicle` varchar(20) NOT NULL,
  `quantity` char(20) NOT NULL,
  `tripsno` varchar(15) NOT NULL,
  `cost` float NOT NULL,
  `total` varchar(10) NOT NULL,
  PRIMARY KEY (`workno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`workno`, `date`, `vehicle`, `quantity`, `tripsno`, `cost`, `total`) VALUES
(1, '0000-00-00', 'truck', '500', '2', 500, '1000'),
(3, '2015-12-22', 'truck', '7', '5', 500, '2500'),
(6, '2015-12-22', 'truck', '200', '2', 500, '1000');
